using System;

class Program
{
    static void Main()
    {
        // Definir os anos de nascimento e ano atual
        int anoNascimento = 2003;
        int anoAtual = 2024;

        // Calcular a diferença de anos
        int idade = anoAtual - anoNascimento;

        // Exibir o resultado
        Console.WriteLine($"A diferença de anos é: {idade} anos.");
    }
}
