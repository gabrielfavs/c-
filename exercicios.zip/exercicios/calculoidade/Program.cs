﻿using System;

class Program
{
    static void Main()
    {
        // Exibir a mensagem para o usuário
        Console.WriteLine("Digite sua data de nascimento:");

        // Ler o ano de nascimento como string e depois converter para inteiro
        int anoNascimento = int.Parse(Console.ReadLine());

        // Definir o ano atual
        int anoAtual = 2024;

        // Calcular a diferença de anos (idade)
        int idade = anoAtual - anoNascimento;

        // Exibir o resultado
        Console.WriteLine($"A diferença de anos é: {idade} anos.");
    }
}
