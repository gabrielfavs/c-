﻿using System;

class Program
{
    static void Main()
    {
        // Solicitar as 3 notas ao usuário
        Console.WriteLine("Digite a primeira nota:");
        double nota1 = double.Parse(Console.ReadLine());

        Console.WriteLine("Digite a segunda nota:");
        double nota2 = double.Parse(Console.ReadLine());

        Console.WriteLine("Digite a terceira nota:");
        double nota3 = double.Parse(Console.ReadLine());

        // Calcular a média
        double media = (nota1 + nota2 + nota3) / 3;

        // Exibir a média
        Console.WriteLine($"A média das notas é: {media}");
    }
}
