﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Digite o primeiro número:");
        int num1 = int.Parse(Console.ReadLine());

        Console.WriteLine("Digite o segundo número:");
        int num2 = int.Parse(Console.ReadLine());
        if (num1 > num2)
        {
            Console.WriteLine($"O maior número é: {num1}");
        }
        else if (num2 > num1)
        {
            Console.WriteLine($"O maior número é: {num2}");
        }
        else
        {
            Console.WriteLine("Os números são iguais.");
        }
    }
}
