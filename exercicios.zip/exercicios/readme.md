Sitema de Alunos 
    - Solicitar o nome de um Alunos
    - Solicitar duas notas numérias (tipo double) referentes ao aluno
    - Calcular  a média aritmética das duas notas

    Exibir
        - Nome do aluno 
        - A média obtida 
        - Status final
            - Aprovado se for maior ou igual a 6.0
            - Reprovado se a média for menor que 6.0
            - Para repositotio