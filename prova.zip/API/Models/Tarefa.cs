﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

public class Tarefa
    {
        public string TarefaId { get; set; } = Guid.NewGuid().ToString();
        public string? Titulo { get; set; }
        public string? Descricao { get; set; }
        public DateTime CriadoEm { get; set; } = DateTime.Now;
        public string? Status { get; set; } = "Não iniciada";
    }

namespace API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TarefaController : ControllerBase
    {
        private static List<Tarefa> tarefas = new List<Tarefa>();

        [HttpGet]
        public IActionResult GetTodasTarefas()
        {
            return Ok(tarefas);
        }

        [HttpGet("{tarefaId}")]
        public IActionResult GetTarefa(string tarefaId)
        {
            var tarefa = GetTarefa(tarefaId);
            if (tarefa == null)
            {
                return NotFound();
            }
            return Ok(tarefa);
        }

        [HttpGet("naoconcluidas")]
        public IActionResult GetTarefasNaoConcluidas()
        {
            var tarefasNaoConcluidas = tarefas
                .Where(t => t.Status == "Não iniciada" || t.Status == "Em andamento")
                .ToList();

            return Ok(tarefasNaoConcluidas);
        }

        [HttpGet("concluidas")]
        public IActionResult GetTarefasConcluidas()
        {
            var tarefasConcluidas = tarefas
                .Where(t => t.Status == "Concluído")
                .ToList();

            return Ok(tarefasConcluidas);
        }

        [HttpPost("{tarefaId}/iniciar")]
        public IActionResult IniciarTarefa(string tarefaId)
        {
            var tarefa = tarefas.FirstOrDefault(t => t.TarefaId == tarefaId);
            if (tarefa == null)
            {
                return NotFound();
            }
            tarefa.Status = "Em andamento";
            return Ok();
        }

        [HttpPost("{tarefaId}/concluir")]
        public IActionResult ConcluirTarefa(string tarefaId)
        {
            var tarefa = tarefas.FirstOrDefault(t => t.TarefaId == tarefaId);
            if (tarefa == null)
            {
                return NotFound();
            }
            tarefa.Status = "Concluído";
            return Ok();
        }

        [HttpPost("{tarefa}")]
        public IActionResult CriarTarefa(Tarefa tarefa)
        {
            tarefas.Add(tarefa);
            return CreatedAtAction(nameof(GetTarefa), new { tarefaId = tarefa.TarefaId }, tarefa);
        }

        private Tarefa GetTarefa(string tarefaId)
        {
            return tarefas.FirstOrDefault(t => t.TarefaId == tarefaId);
        }
    }

    
}
