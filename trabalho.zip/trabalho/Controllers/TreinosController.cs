using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

[ApiController]
[Route("[controller]")]
public class TreinosController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public TreinosController(ApplicationDbContext context)
    {
        _context = context;
    }

    // Métodos GET, POST, PUT e DELETE para Treinos
}
