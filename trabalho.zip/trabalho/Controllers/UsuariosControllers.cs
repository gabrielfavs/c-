using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UsuariosController
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        private readonly ApplicationDbContext _dbContext;

        public UsuariosController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpPost]
        public async Task<ActionResult<Usuario>> CriarUsuario([FromBody] Usuario usuario)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _dbContext.Usuarios.Add(usuario);
            await _dbContext.SaveChangesAsync();
            return CreatedAtAction(nameof(ObterUsuario), new { id = usuario.Id }, usuario);
        }

        [HttpGet]
        public IEnumerable<Usuario> ListarUsuarios()
        {
            return _dbContext.Usuarios.ToList();
        }

        [HttpGet("{id}")]
        public ActionResult<Usuario> ObterUsuario(int id)
        {
            var usuario = _dbContext.Usuarios.Find(id);
            if (usuario == null)
                return NotFound();

            return usuario;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> AtualizarUsuario(int id, [FromBody] Usuario usuarioAtualizado)
        {
            if (id != usuarioAtualizado.Id)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            _dbContext.Entry(usuarioAtualizado).State = EntityState.Modified;

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_dbContext.Usuarios.Any(u => u.Id == id))
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletarUsuario(int id)
        {
            var usuario = await _dbContext.Usuarios.FindAsync(id);
            if (usuario == null)
                return NotFound();

            _dbContext.Usuarios.Remove(usuario);
            await _dbContext.SaveChangesAsync();

            return NoContent();
        }

        [HttpGet("pesquisar")]
        public IEnumerable<Usuario> PesquisarUsuariosPorNome(string nome)
        {
            return _dbContext.Usuarios.Where(u => u.Nome.Contains(nome)).ToList();
        }
    }
}
