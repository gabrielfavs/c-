using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

public class ApplicationDbContext : DbContext
{
    public DbSet<Usuario> Usuarios { get; set; }
    public DbSet<Treino> Treinos { get; set; }
    public DbSet<Matricula> Matriculas { get; set; }
    public DbSet<Pagamento> Pagamentos { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        var connectionStringBuilder = new SqliteConnectionStringBuilder { DataSource = "academia.db" };
        var connectionString = connectionStringBuilder.ToString();
        var connection = new SqliteConnection(connectionString);

        optionsBuilder.UseSqlite(connection);
    }
}

public class Usuario
{
    public int Id { get; set; }
    [Required]
    public string Nome { get; set; }
    [Required]
    public string Email { get; set; }
    [Required]
    public string Senha { get; set; }
}

public class Treino
{
    public int Id { get; set; }
    [Required]
    public string Nome { get; set; }
    public string Descricao { get; set; }
    public int DuracaoMinutos { get; set; }
}

public class Matricula
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public Usuario Usuario { get; set; }
    public int TreinoId { get; set; }
    public Treino Treino { get; set; }
    public DateTime DataInicio { get; set; }
    public bool Ativo { get; set; }
}

public class Pagamento
{
    public int Id { get; set; }
    public int UsuarioId { get; set; }
    public Usuario Usuario { get; set; }
    public decimal Valor { get; set; }
    public DateTime DataPagamento { get; set; }
    public string MetodoPagamento { get; set; }
}

public class Program
{
    public static async Task Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        builder.Services.AddControllers();
        builder.Services.AddDbContext<ApplicationDbContext>();

        var app = builder.Build();

        using (var scope = app.Services.CreateScope())
        {
            var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
            await dbContext.Database.EnsureCreatedAsync();
        }

        app.MapControllers();

        app.Run();
    }
}

public class UsuariosController : ControllerBase
{
    private readonly ApplicationDbContext _dbContext;

    public UsuariosController(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    [HttpPost("/usuarios")]
    public async Task<ActionResult<Usuario>> CriarUsuario([FromBody] Usuario usuario)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _dbContext.Usuarios.Add(usuario);
        await _dbContext.SaveChangesAsync();
        return CreatedAtAction(nameof(ObterUsuario), new { id = usuario.Id }, usuario);
    }

    [HttpGet("/usuarios")]
    public IEnumerable<Usuario> ListarUsuarios()
    {
        return _dbContext.Usuarios.ToList();
    }

    [HttpGet("/usuarios/{id}")]
    public ActionResult<Usuario> ObterUsuario(int id)
    {
        var usuario = _dbContext.Usuarios.Find(id);
        if (usuario == null)
            return NotFound();

        return usuario;
    }

    [HttpPut("/usuarios/{id}")]
    public async Task<IActionResult> AtualizarUsuario(int id, [FromBody] Usuario usuarioAtualizado)
    {
        if (id != usuarioAtualizado.Id)
            return BadRequest();

        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _dbContext.Entry(usuarioAtualizado).State = EntityState.Modified;

        try
        {
            await _dbContext.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!_dbContext.Usuarios.Any(u => u.Id == id))
                return NotFound();
            else
                throw;
        }

        return NoContent();
    }

    [HttpDelete("/usuarios/{id}")]
    public async Task<IActionResult> DeletarUsuario(int id)
    {
        var usuario = await _dbContext.Usuarios.FindAsync(id);
        if (usuario == null)
            return NotFound();

        _dbContext.Usuarios.Remove(usuario);
        await _dbContext.SaveChangesAsync();

        return NoContent();
    }
}

public class TreinosController : ControllerBase
{
    private readonly ApplicationDbContext _dbContext;

    public TreinosController(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    [HttpPost("/treinos")]
    public async Task<ActionResult<Treino>> CriarTreino([FromBody] Treino treino)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _dbContext.Treinos.Add(treino);
        await _dbContext.SaveChangesAsync();
        return CreatedAtAction(nameof(ObterTreino), new { id = treino.Id }, treino);
    }

    [HttpGet("/treinos")]
    public IEnumerable<Treino> ListarTreinos()
    {
        return _dbContext.Treinos.ToList();
    }

    [HttpGet("/treinos/{id}")]
    public ActionResult<Treino> ObterTreino(int id)
    {
        var treino = _dbContext.Treinos.Find(id);
        if (treino == null)
            return NotFound();

        return treino;
    }

    [HttpPut("/treinos/{id}")]
    public async Task<IActionResult> AtualizarTreino(int id, [FromBody] Treino treinoAtualizado)
    {
        if (id != treinoAtualizado.Id)
            return BadRequest();

        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _dbContext.Entry(treinoAtualizado).State = EntityState.Modified;

        try
        {
            await _dbContext.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!_dbContext.Treinos.Any(t => t.Id == id))
                return NotFound();
            else
                throw;
        }

        return NoContent();
    }

    [HttpDelete("/treinos/{id}")]
    public async Task<IActionResult> DeletarTreino(int id)
    {
        var treino = await _dbContext.Treinos.FindAsync(id);
        if (treino == null)
            return NotFound();

        _dbContext.Treinos.Remove(treino);
        await _dbContext.SaveChangesAsync();

        return NoContent();
    }
}

public class MatriculasController : ControllerBase
{
    private readonly ApplicationDbContext _dbContext;

    public MatriculasController(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    [HttpPost("/matriculas")]
    public async Task<ActionResult<Matricula>> CriarMatricula([FromBody] Matricula matricula)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _dbContext.Matriculas.Add(matricula);
        await _dbContext.SaveChangesAsync();
        return CreatedAtAction(nameof(ObterMatricula), new { id = matricula.Id }, matricula);
    }

    [HttpGet("/matriculas")]
    public IEnumerable<Matricula> ListarMatriculas()
    {
        return _dbContext.Matriculas.ToList();
    }

    [HttpGet("/matriculas/{id}")]
    public ActionResult<Matricula> ObterMatricula(int id)
    {
        var matricula = _dbContext.Matriculas.Find(id);
        if (matricula == null)
            return NotFound();

        return matricula;
    }

    [HttpPut("/matriculas/{id}")]
    public async Task<IActionResult> AtualizarMatricula(int id, [FromBody] Matricula matriculaAtualizada)
    {
        if (id != matriculaAtualizada.Id)
            return BadRequest();

        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _dbContext.Entry(matriculaAtualizada).State = EntityState.Modified;

        try
        {
            await _dbContext.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!_dbContext.Matriculas.Any(m => m.Id == id))
                return NotFound();
            else
                throw;
        }

        return NoContent();
    }

    [HttpDelete("/matriculas/{id}")]
    public async Task<IActionResult> DeletarMatricula(int id)
    {
        var matricula = await _dbContext.Matriculas.FindAsync(id);
        if (matricula == null)
            return NotFound();

        _dbContext.Matriculas.Remove(matricula);
        await _dbContext.SaveChangesAsync();

        return NoContent();
    }
}

public class PagamentosController : ControllerBase
{
    private readonly ApplicationDbContext _dbContext;

    public PagamentosController(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    [HttpPost("/pagamentos")]
    public async Task<ActionResult<Pagamento>> CriarPagamento([FromBody] Pagamento pagamento)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _dbContext.Pagamentos.Add(pagamento);
        await _dbContext.SaveChangesAsync();
        return CreatedAtAction(nameof(ObterPagamento), new { id = pagamento.Id }, pagamento);
    }

    [HttpGet("/pagamentos")]
    public IEnumerable<Pagamento> ListarPagamentos()
    {
        return _dbContext.Pagamentos.ToList();
    }

    [HttpGet("/pagamentos/{id}")]
    public ActionResult<Pagamento> ObterPagamento(int id)
    {
        var pagamento = _dbContext.Pagamentos.Find(id);
        if (pagamento == null)
            return NotFound();

        return pagamento;
    }

    [HttpPut("/pagamentos/{id}")]
    public async Task<IActionResult> AtualizarPagamento(int id, [FromBody] Pagamento pagamentoAtualizado)
    {
        if (id != pagamentoAtualizado.Id)
            return BadRequest();

        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        _dbContext.Entry(pagamentoAtualizado).State = EntityState.Modified;

        try
        {
            await _dbContext.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!_dbContext.Pagamentos.Any(p => p.Id == id))
                return NotFound();
            else
                throw;
        }

        return NoContent();
    }

    [HttpDelete("/pagamentos/{id}")]
    public async Task<IActionResult> DeletarPagamento(int id)
    {
        var pagamento = await _dbContext.Pagamentos.FindAsync(id);
        if (pagamento == null)
            return NotFound();

        _dbContext.Pagamentos.Remove(pagamento);
        await _dbContext.SaveChangesAsync();

        return NoContent();
    }
}
